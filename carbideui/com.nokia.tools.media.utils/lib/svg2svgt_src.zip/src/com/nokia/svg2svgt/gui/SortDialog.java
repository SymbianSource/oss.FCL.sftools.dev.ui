/*
* Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies). 
* All rights reserved.
* This component and the accompanying materials are made available
* under the terms of the License "Symbian Foundation License v1.0"
* which accompanies this distribution, and is available
* at the URL "http://www.symbianfoundation.org/legal/sfl-v10.html".
*
* Initial Contributors:
* Nokia Corporation - initial contribution.
*
* Contributors:
*
* Description:
*
*/

package com.nokia.svg2svgt.gui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

public class SortDialog extends JDialog implements MouseListener,
		ListSelectionListener, FocusListener {

	JList list;
	private JScrollPane listScroll;
	private Vector listContents = new Vector();
	private Object[] selection;
	public static Vector v = new Vector();
	private Vector txtFieldVector = new Vector();
	private boolean isDisposed = true;
	private JDialog addDialog = null;

	public SortDialog(JDialog dialog, boolean modal) {
		super(dialog, " ", false);
		addDialog = dialog;
		setUndecorated(true);
		list = new JList();

		listScroll = new JScrollPane(list);
		list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		list
				.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1,
						Color.BLACK));
		list.addMouseListener(this);
		this.getContentPane().add(listScroll, null);
		this.setSize(new Dimension(180, 136));
	}

	public void mouseClicked(MouseEvent e) {
	}

	public void dispose() {
		setDisposed(true);
		super.dispose();
	}

	public void show() {
		setDisposed(false);
		super.setVisible(true);
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void valueChanged(ListSelectionEvent e) {
	}

	public void focusGained(FocusEvent e) {
	}

	public void focusLost(FocusEvent e) {
		this.dispose();
	}

	public boolean isDisposed() {
		return isDisposed;
	}

	public void setDisposed(boolean b) {
		isDisposed = b;
	}

}
