/*
* Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies). 
* All rights reserved.
* This component and the accompanying materials are made available
* under the terms of the License "Symbian Foundation License v1.0"
* which accompanies this distribution, and is available
* at the URL "http://www.symbianfoundation.org/legal/sfl-v10.html".
*
* Initial Contributors:
* Nokia Corporation - initial contribution.
*
* Contributors:
*
* Description:
*
*/
package com.nokia.svg2svgt.gui;

/**
 * <code>SVGTConverterModel</code> forms the model for the converter tool view.
 * The model is created only if the tool is launched in the stand alone mode.
 * 
 */
public class SVGTConverterModel {

	/**
	 * Creates the model for the <code>SVGTConverterView</code> view.
	 */
	public SVGTConverterModel() {
		// contains a queue containing all the log events being shown on the
		// screen
	}
}
