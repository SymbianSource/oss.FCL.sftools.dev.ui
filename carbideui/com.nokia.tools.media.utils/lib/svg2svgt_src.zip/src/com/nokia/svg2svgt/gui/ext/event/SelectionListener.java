/*
* Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies). 
* All rights reserved.
* This component and the accompanying materials are made available
* under the terms of the License "Symbian Foundation License v1.0"
* which accompanies this distribution, and is available
* at the URL "http://www.symbianfoundation.org/legal/sfl-v10.html".
*
* Initial Contributors:
* Nokia Corporation - initial contribution.
*
* Contributors:
*
* Description:
*
*/

package com.nokia.svg2svgt.gui.ext.event;

import java.util.EventListener;

public interface SelectionListener extends EventListener {
    public void selectionChanged (SelectionEvent e);
    public void selectionOver (SelectionEvent e);
}
